def fn_var():
    bucket_name = 'llm_gateway'
    source_blob_name = 'diamonds.csv'
    destination_file_name = 'diamonds.csv'
    return (bucket_name,source_blob_name,destination_file_name)
